#pragma once
template<typename T>
class item_data {
public:
	T value;
	item_data<T> *prev;
	item_data<T> *next;
};

template<typename T>
class Deque
{
public:
	Deque(){}
	~Deque(){}
	void push_back(T);
	void push_front(T);
	void pop();
	const T& back_value();
	void clear();
	size_t size();
private:
	item_data<T>* data_back;
	item_data<T>* data_front;
	size_t _size;
};
