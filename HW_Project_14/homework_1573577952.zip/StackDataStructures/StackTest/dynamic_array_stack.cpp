#include "dynamic_array_stack.h"

dynamic_array_stack::dynamic_array_stack(int count):
	max_count{count},
	last_item{-1}
{
	data = new int[max_count];
}

dynamic_array_stack::~dynamic_array_stack()
{
	delete[] data;
}

bool dynamic_array_stack::push(int temp)
{
	last_item++;
	if (max_count > last_item) {
		data[last_item] = temp;
		return true;
	}
	return false;
}

void dynamic_array_stack::pop()
{
	if (last_item > -1) {
		last_item--;
	}
}

const int& dynamic_array_stack::top()
{
	if (last_item >= 0) {
		return data[last_item];
	}
	return last_item;
}

bool dynamic_array_stack::empty()
{
	return (last_item < 0);
}

int dynamic_array_stack::size()
{
	return (last_item + 1);
}
