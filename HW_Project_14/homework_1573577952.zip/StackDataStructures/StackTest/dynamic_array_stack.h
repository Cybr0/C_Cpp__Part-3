#pragma once
class dynamic_array_stack
{
public:
	dynamic_array_stack(int count);
	~dynamic_array_stack();
	bool push(int);
	void pop();
	const int& top();
	bool empty();
	int size();
private:
	int* data;
	int last_item;
	int max_count;
};

