﻿#include <iostream>
#include <queue>
#include <deque>
#include "Deque.h"
#include <initializer_list>
#include <list>
#include <vector>
int main()
{
	Deque<int> dq{1,2,3};
	/*dq.push_back(1);
	dq.push_back(2);
	dq.push_back(3);*/
	//dq.clear();
	for (size_t i = 0; i < dq.size(); i++)
	{
		std::cout << dq[i];
	}
	std::cout << std::endl;
	dq.clear();
	dq.push_front(1);
	dq.push_front(2);
	dq.push_front(3);
	//dq.clear();

	//while (dq.size() > 0)
	//{
	//	std::cout << dq.back_value();
	//	dq.pop();
	//}

	for (size_t i = 0; i < dq.size(); i++)
	{
		std::cout << dq[i];
	}
}