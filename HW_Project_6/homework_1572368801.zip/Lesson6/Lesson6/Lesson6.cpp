﻿#include <iostream>
#include "Book.h"

int main()
{
	Book b = std::string("New book");
	std::cout << b.book_name() << std::endl;
	Book b1(100);
	std::cout << b1.published_year() << std::endl;
}

