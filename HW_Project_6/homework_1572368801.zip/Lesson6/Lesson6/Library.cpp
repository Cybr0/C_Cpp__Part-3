#include "Library.h"



Library::Library()
{
}


Library::~Library()
{
}

void Library::add_book(Book new_item) 
{
	Book* arr = new Book[size+1];
	for (size_t i = 0; i < size; i++) {
		arr[i] = book_list[i];
	}	
	arr[size] = new_item;
	if(size > 0){
		delete[]book_list;
	}
	book_list = arr;
	size++;
}

void Library::rem_book(size_t index)
{
}

void Library::show_by_autor(std::string name) const
{
}

void Library::show_by_publisher(std::string name) const
{
}

void Library::show_after_year(int) const
{
}
