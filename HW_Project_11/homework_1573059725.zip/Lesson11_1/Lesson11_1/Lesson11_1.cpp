﻿#include <iostream>
#include "String.h"

//Семантика перемещения
//move 

int main()
{
	String str_a = "string test";
	String str_b = str_a;
	return 0;
}

