#include "pch.h"
#include "Array.h"

TEST(TestCaseName, TestName) {
	Array<int> arr;
  EXPECT_EQ(arr.size(), 0);

  EXPECT_TRUE(true);

}