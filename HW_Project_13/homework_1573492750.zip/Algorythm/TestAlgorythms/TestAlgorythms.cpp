﻿#include <iostream>
#include "Array.h"

int main()
{
    std::cout << "Hello World!\n"; 
}
