#include "Worker.h"

Worker::Worker()
{
	
}


Worker::~Worker()
{
}

std::string Worker::name()
{
	return _name;
}

double Worker::salary()
{
	return _salary;
}

int Worker::stage()
{
	return _stage;
}
